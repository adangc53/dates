<?php 
print date("Y-m-d");

?>