$(document).ready(function()
{
    var compruebano =$("#NoAsociado").val();
}); 